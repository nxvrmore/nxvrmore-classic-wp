<?php
/*
 * Función para duplicar páginas y entradas
 */
function nxvrmore_duplicate_post() {
    if (isset($_GET['action']) && $_GET['action'] == 'duplicate_post' && isset($_GET['post'])) {
        $post_id = intval($_GET['post']);
        $post = get_post($post_id);

        if ($post) {
            $current_user = wp_get_current_user();
            $new_post = array(
                'post_title'    => $post->post_title . ' (Copia)',
                'post_content'  => $post->post_content,
                'post_status'   => 'draft',
                'post_author'   => $current_user->ID,
                'post_type'     => $post->post_type,
                'post_excerpt'  => $post->post_excerpt,
                'post_parent'   => $post->post_parent,
                'post_password' => $post->post_password,
                'comment_status' => $post->comment_status,
                'ping_status'    => $post->ping_status,
                'to_ping'        => $post->to_ping,
                'menu_order'     => $post->menu_order
            );

            $new_post_id = wp_insert_post($new_post);

            // Duplicar taxonomías
            $taxonomies = get_object_taxonomies($post->post_type);
            foreach ($taxonomies as $taxonomy) {
                $post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
                wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
            }

            // Duplicar metadatos
            $post_meta = get_post_meta($post_id);
            foreach ($post_meta as $meta_key => $meta_values) {
                foreach ($meta_values as $meta_value) {
                    add_post_meta($new_post_id, $meta_key, $meta_value);
                }
            }

            wp_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
            exit;
        }
    }
}
add_action('admin_action_duplicate_post', 'nxvrmore_duplicate_post');

// Añadir enlace "Duplicar" en la lista de páginas/entradas
function nxvrmore_duplicate_post_link($actions, $post) {
    if (current_user_can('edit_posts')) {
        $actions['duplicate'] = '<a href="' . wp_nonce_url(admin_url('admin.php?action=duplicate_post&post=' . $post->ID), 'duplicate_post_' . $post->ID) . '" title="Duplicar este elemento" rel="permalink">Duplicar</a>';
    }
    return $actions;
}
add_filter('post_row_actions', 'nxvrmore_duplicate_post_link', 10, 2);
add_filter('page_row_actions', 'nxvrmore_duplicate_post_link', 10, 2);