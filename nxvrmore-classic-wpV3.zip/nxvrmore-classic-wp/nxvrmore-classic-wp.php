<?php
/*
Plugin Name: Nxvrmore Classic WP
Plugin URI: https://github.com/nxvrmore/nxvrmore-classic-wp
Description: Este plugin activa el editor clásico de WordPress, desactiva el editor de bloques para widgets, establece los enlaces permanentes como 'Nombre de la entrada', deshabilita la barra de herramientas para todos los usuarios (incluido el administrador), elimina plugins y contenido por defecto de WordPress. Además, permite duplicar páginas y entradas, incluyendo las creadas con Elementor, y añadir código PHP y JS personalizado.
Version: 1.6
Author: Nxvrmore
Author URI: https://github.com/nxvrmore
License: GPL2
*/

// Añadir menú de configuración
function nxvrmore_add_admin_menu() {
    add_submenu_page(
        'tools.php', // Parent slug (Herramientas)
        'Nxvrmore Classic WP', // Título de la página
        'Nxvrmore Classic WP', // Título del menú
        'manage_options', // Capacidad requerida
        'nxvrmore-classic-wp', // Slug del menú
        'nxvrmore_options_page' // Función de callback
    );
}
add_action('admin_menu', 'nxvrmore_add_admin_menu');

// Registrar opciones
function nxvrmore_register_settings() {
    register_setting('nxvrmore_options_group', 'nxvrmore_options', 'nxvrmore_options_validate');

    add_settings_section('nxvrmore_main_section', 'Configuración General', 'nxvrmore_section_text', 'nxvrmore-classic-wp');

    add_settings_field('nxvrmore_classic_editor', 'Activar Editor Clásico', 'nxvrmore_classic_editor_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_classic_widgets', 'Activar Widgets Clásicos', 'nxvrmore_classic_widgets_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_permalink_structure', 'Establecer Enlaces Permanentes', 'nxvrmore_permalink_structure_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_disable_admin_bar', 'Deshabilitar Barra de Herramientas', 'nxvrmore_disable_admin_bar_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_remove_default_plugins', 'Eliminar Plugins por Defecto', 'nxvrmore_remove_default_plugins_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_remove_default_content', 'Eliminar Contenido por Defecto', 'nxvrmore_remove_default_content_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_duplicate', 'Activar Duplicar Páginas/Entradas', 'nxvrmore_enable_duplicate_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_custom_php', 'Activar Código PHP Personalizado', 'nxvrmore_enable_custom_php_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_custom_php_code', 'Código PHP Personalizado', 'nxvrmore_custom_php_code_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_custom_js', 'Activar Código JS Personalizado', 'nxvrmore_enable_custom_js_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_custom_js_code', 'Código JS Personalizado', 'nxvrmore_custom_js_code_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_disable_file_edit', 'Desactivar Edición de Archivos', 'nxvrmore_disable_file_edit_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_hide_wp_version', 'Ocultar Versión de WordPress', 'nxvrmore_hide_wp_version_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_protect_woocommerce', 'Proteger WooCommerce', 'nxvrmore_protect_woocommerce_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_disable_xmlrpc', 'Desactivar XML-RPC', 'nxvrmore_disable_xmlrpc_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_ip_blocking', 'Activar Bloqueo de IPs Maliciosas', 'nxvrmore_enable_ip_blocking_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_abuseipdb_api_key', 'API Key de AbuseIPDB', 'nxvrmore_abuseipdb_api_key_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
}
add_action('admin_init', 'nxvrmore_register_settings');

// Texto de la sección
function nxvrmore_section_text() {
    echo '<p>Configura las opciones del plugin Nxvrmore Classic WP.</p>';
}

// Campos de entrada con switches personalizados
function nxvrmore_classic_editor_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_classic_editor" name="nxvrmore_options[classic_editor]" value="1" ' . checked(1, $options['classic_editor'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_classic_widgets_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_classic_widgets" name="nxvrmore_options[classic_widgets]" value="1" ' . checked(1, $options['classic_widgets'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_permalink_structure_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_permalink_structure" name="nxvrmore_options[permalink_structure]" value="1" ' . checked(1, $options['permalink_structure'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_disable_admin_bar_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_disable_admin_bar" name="nxvrmore_options[disable_admin_bar]" value="1" ' . checked(1, $options['disable_admin_bar'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_remove_default_plugins_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_remove_default_plugins" name="nxvrmore_options[remove_default_plugins]" value="1" ' . checked(1, $options['remove_default_plugins'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_remove_default_content_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_remove_default_content" name="nxvrmore_options[remove_default_content]" value="1" ' . checked(1, $options['remove_default_content'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_enable_duplicate_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_duplicate" name="nxvrmore_options[enable_duplicate]" value="1" ' . checked(1, $options['enable_duplicate'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_enable_custom_php_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_custom_php" name="nxvrmore_options[enable_custom_php]" value="1" ' . checked(1, $options['enable_custom_php'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_custom_php_code_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <div class="nxvrmore-php-code-field nxvrmore-code-field">
        <textarea id="nxvrmore_custom_php_code" name="nxvrmore_options[custom_php_code]" class="nxvrmore-php-code">' . esc_textarea($options['custom_php_code'] ?? '') . '</textarea>
    </div>
    ';
}

function nxvrmore_enable_custom_js_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_custom_js" name="nxvrmore_options[enable_custom_js]" value="1" ' . checked(1, $options['enable_custom_js'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_custom_js_code_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <div class="nxvrmore-js-code-field nxvrmore-code-field">
        <textarea id="nxvrmore_custom_js_code" name="nxvrmore_options[custom_js_code]" class="nxvrmore-js-code">' . esc_textarea($options['custom_js_code'] ?? '') . '</textarea>
    </div>
    ';
}

function nxvrmore_disable_file_edit_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_disable_file_edit" name="nxvrmore_options[disable_file_edit]" value="1" ' . checked(1, $options['disable_file_edit'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_hide_wp_version_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_hide_wp_version" name="nxvrmore_options[hide_wp_version]" value="1" ' . checked(1, $options['hide_wp_version'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_protect_woocommerce_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_protect_woocommerce" name="nxvrmore_options[protect_woocommerce]" value="1" ' . checked(1, $options['protect_woocommerce'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_disable_xmlrpc_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_disable_xmlrpc" name="nxvrmore_options[disable_xmlrpc]" value="1" ' . checked(1, $options['disable_xmlrpc'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_enable_ip_blocking_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_ip_blocking" name="nxvrmore_options[enable_ip_blocking]" value="1" ' . checked(1, $options['enable_ip_blocking'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_abuseipdb_api_key_input() {
    $options = get_option('nxvrmore_options', array());
    $api_key = $options['abuseipdb_api_key'] ?? '';
    $disabled = !empty($api_key) ? 'disabled' : '';
    echo '
    <input type="text" id="nxvrmore_abuseipdb_api_key" name="nxvrmore_options[abuseipdb_api_key]" value="' . esc_attr($api_key) . '" class="regular-text" ' . $disabled . ' />
    <p class="description">Introduce tu API Key de AbuseIPDB para bloquear IPs maliciosas.</p>
    ';
    if (!empty($api_key)) {
        echo '
        <button type="button" id="nxvrmore_disconnect_api" class="button button-secondary">Desactivar API</button>
        ';
    }
}

// Página de opciones
function nxvrmore_options_page() {
    ?>
    <div class="wrap">
        <h1>Nxvrmore Classic WP</h1>
        <?php settings_errors(); ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('nxvrmore_options_group');
            do_settings_sections('nxvrmore-classic-wp');
            submit_button('Guardar Cambios');
            ?>
        </form>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const successMessage = document.querySelector('.notice.updated');
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 5000); // Ocultar el mensaje después de 5 segundos
            }

            // Manejar el botón "Desactivar API"
            const disconnectButton = document.getElementById('nxvrmore_disconnect_api');
            if (disconnectButton) {
                disconnectButton.addEventListener('click', function() {
                    const apiKeyField = document.getElementById('nxvrmore_abuseipdb_api_key');
                    apiKeyField.value = '';
                    apiKeyField.disabled = false;
                    disconnectButton.remove();
                });
            }
        });
    </script>
    <style>
        .nxvrmore-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .nxvrmore-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .nxvrmore-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: 0.4s;
            border-radius: 34px;
        }

        .nxvrmore-slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: 0.4s;
            border-radius: 50%;
        }

        input:checked + .nxvrmore-slider {
            background-color: #2196F3;
        }

        input:checked + .nxvrmore-slider:before {
            transform: translateX(26px);
        }

        .nxvrmore-code-field textarea {
            width: 100%;
            height: 200px;
            font-family: monospace;
        }

        .notice.updated {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            padding: 15px;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
    </style>
    <?php
}

// Validar opciones
if (!function_exists('nxvrmore_options_validate')) {
    function nxvrmore_options_validate($input) {
        $newinput = array();

        // Validar y guardar todas las opciones
        $newinput['classic_editor'] = isset($input['classic_editor']) ? 1 : 0;
        $newinput['classic_widgets'] = isset($input['classic_widgets']) ? 1 : 0;
        $newinput['permalink_structure'] = isset($input['permalink_structure']) ? 1 : 0;
        $newinput['disable_admin_bar'] = isset($input['disable_admin_bar']) ? 1 : 0;
        $newinput['remove_default_plugins'] = isset($input['remove_default_plugins']) ? 1 : 0;
        $newinput['remove_default_content'] = isset($input['remove_default_content']) ? 1 : 0;
        $newinput['enable_duplicate'] = isset($input['enable_duplicate']) ? 1 : 0;
        $newinput['enable_custom_php'] = isset($input['enable_custom_php']) ? 1 : 0;
        $newinput['enable_custom_js'] = isset($input['enable_custom_js']) ? 1 : 0;
        $newinput['disable_file_edit'] = isset($input['disable_file_edit']) ? 1 : 0;
        $newinput['hide_wp_version'] = isset($input['hide_wp_version']) ? 1 : 0;
        $newinput['protect_woocommerce'] = isset($input['protect_woocommerce']) ? 1 : 0;
        $newinput['disable_xmlrpc'] = isset($input['disable_xmlrpc']) ? 1 : 0;
        $newinput['enable_ip_blocking'] = isset($input['enable_ip_blocking']) ? 1 : 0;

        // Validar el código PHP antes de guardarlo
        if (isset($input['custom_php_code']) && !empty($input['custom_php_code'])) {
            $code = $input['custom_php_code'];
            $valid = nxvrmore_validate_php_code($code);
            if ($valid) {
                $newinput['custom_php_code'] = $code;
            } else {
                add_settings_error('nxvrmore_options', 'invalid_php', 'El código PHP contiene errores y no se ha guardado.', 'error');
                $newinput['custom_php_code'] = '';
                $newinput['enable_custom_php'] = 0; // Desactivar si hay errores
            }
        } else {
            $newinput['custom_php_code'] = '';
        }

        // Validar el código JS antes de guardarlo
        if (isset($input['custom_js_code']) && !empty($input['custom_js_code'])) {
            $newinput['custom_js_code'] = $input['custom_js_code'];
        } else {
            $newinput['custom_js_code'] = '';
        }

        // Validar la API Key de AbuseIPDB
        if (isset($input['abuseipdb_api_key']) && !empty($input['abuseipdb_api_key'])) {
            $api_key = $input['abuseipdb_api_key'];
            $valid = nxvrmore_validate_abuseipdb_api_key($api_key);
            if ($valid) {
                $newinput['abuseipdb_api_key'] = $api_key;
                add_settings_error('nxvrmore_options', 'api_key_valid', 'La API Key de AbuseIPDB es válida y se ha guardado con éxito.', 'updated');
            } else {
                add_settings_error('nxvrmore_options', 'invalid_api_key', 'La API Key de AbuseIPDB no es válida.', 'error');
                $newinput['abuseipdb_api_key'] = '';
                $newinput['enable_ip_blocking'] = 0; // Desactivar si la API Key no es válida
            }
        } else {
            $newinput['abuseipdb_api_key'] = '';
        }

        return $newinput;
    }
}

// Validar código PHP
if (!function_exists('nxvrmore_validate_php_code')) {
    function nxvrmore_validate_php_code($code) {
        ob_start();
        $valid = true;
        try {
            eval($code);
        } catch (Throwable $e) {
            $valid = false;
        }
        ob_end_clean();
        return $valid;
    }
}

// Validar API Key de AbuseIPDB
if (!function_exists('nxvrmore_validate_abuseipdb_api_key')) {
    function nxvrmore_validate_abuseipdb_api_key($api_key) {
        $url = "https://api.abuseipdb.com/api/v2/check";
        $args = array(
            'headers' => array(
                'Key' => $api_key,
                'Accept' => 'application/json',
            ),
            'body' => array(
                'ipAddress' => '127.0.0.1',
                'maxAgeInDays' => '90',
            ),
        );

        $response = wp_remote_get($url, $args);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        return isset($data['data']) && !isset($data['errors']);
    }
}

// Activar el editor clásico
function nxvrmore_activate_classic_editor() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['classic_editor']) && $options['classic_editor']) {
        add_filter('use_block_editor_for_post', '__return_false', 10);
        add_filter('use_block_editor_for_post_type', '__return_false', 10);
    }
}
add_action('init', 'nxvrmore_activate_classic_editor');

// Ejecutar código PHP personalizado si está activado
function nxvrmore_execute_custom_php() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['enable_custom_php']) && $options['enable_custom_php'] && !empty($options['custom_php_code'])) {
        try {
            eval($options['custom_php_code']);
        } catch (Throwable $e) {
            // Desactivar el código si hay un error
            $options['enable_custom_php'] = 0;
            update_option('nxvrmore_options', $options);
        }
    }
}
add_action('init', 'nxvrmore_execute_custom_php');

// Insertar código JS en todas las páginas
function nxvrmore_insert_custom_js() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['enable_custom_js']) && $options['enable_custom_js'] && !empty($options['custom_js_code'])) {
        echo '<script type="text/javascript">' . $options['custom_js_code'] . '</script>';
    }
}
add_action('wp_footer', 'nxvrmore_insert_custom_js');

// Desactivar la edición de archivos
function nxvrmore_disable_file_edit() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['disable_file_edit']) && $options['disable_file_edit']) {
        if (!defined('DISALLOW_FILE_EDIT')) {
            define('DISALLOW_FILE_EDIT', true);
        }
    }
}
add_action('init', 'nxvrmore_disable_file_edit');

// Ocultar la versión de WordPress
function nxvrmore_hide_wp_version() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['hide_wp_version']) && $options['hide_wp_version']) {
        remove_action('wp_head', 'wp_generator');
    }
}
add_action('init', 'nxvrmore_hide_wp_version');

// Proteger WooCommerce
function nxvrmore_protect_woocommerce() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['protect_woocommerce']) && $options['protect_woocommerce']) {
        $htaccess_content = "<FilesMatch \"^(woocommerce|wc-api|wc-auth|wc-login)\.php$\">\n  Order Deny,Allow\n  Deny from all\n</FilesMatch>";
        $htaccess_path = ABSPATH . '.htaccess';
        if (file_exists($htaccess_path)) {
            file_put_contents($htaccess_path, $htaccess_content . PHP_EOL, FILE_APPEND);
        }
    }
}
add_action('init', 'nxvrmore_protect_woocommerce');

// Desactivar XML-RPC
function nxvrmore_disable_xmlrpc() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['disable_xmlrpc']) && $options['disable_xmlrpc']) {
        add_filter('xmlrpc_enabled', '__return_false');
    }
}
add_action('init', 'nxvrmore_disable_xmlrpc');

// Bloquear IPs maliciosas
function nxvrmore_block_malicious_ips() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['enable_ip_blocking']) && $options['enable_ip_blocking'] && !empty($options['abuseipdb_api_key'])) {
        $user_ip = $_SERVER['REMOTE_ADDR'];
        $api_key = $options['abuseipdb_api_key'];

        $url = "https://api.abuseipdb.com/api/v2/check";
        $args = array(
            'headers' => array(
                'Key' => $api_key,
                'Accept' => 'application/json',
            ),
            'body' => array(
                'ipAddress' => $user_ip,
                'maxAgeInDays' => '90',
            ),
        );

        $response = wp_remote_get($url, $args);

        if (!is_wp_error($response)) {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (isset($data['data']['abuseConfidenceScore']) && $data['data']['abuseConfidenceScore'] > 0) {
                wp_die('Acceso denegado. Tu IP ha sido identificada como maliciosa.', 'Acceso Denegado', array('response' => 403));
            }
        }
    }
}
add_action('init', 'nxvrmore_block_malicious_ips');