<?php
/*
Plugin Name: Nxvrmore Classic WP
Plugin URI: https://github.com/nxvrmore/nxvrmore-classic-wp
Description: Este plugin activa el editor clásico de WordPress, desactiva el editor de bloques para widgets, establece los enlaces permanentes como 'Nombre de la entrada', deshabilita la barra de herramientas para todos los usuarios (incluido el administrador), elimina plugins y contenido por defecto de WordPress. Además, permite duplicar páginas y entradas, incluyendo las creadas con Elementor, y añadir código PHP y JS personalizado.
Version: 1.5
Author: Nxvrmore
Author URI: https://github.com/nxvrmore
License: GPL2
*/

// Añadir menú de configuración
function nxvrmore_add_admin_menu() {
    add_submenu_page(
        'tools.php', // Parent slug (Herramientas)
        'Nxvrmore Classic WP', // Título de la página
        'Nxvrmore Classic WP', // Título del menú
        'manage_options', // Capacidad requerida
        'nxvrmore-classic-wp', // Slug del menú
        'nxvrmore_options_page' // Función de callback
    );
}
add_action('admin_menu', 'nxvrmore_add_admin_menu');

// Registrar opciones
function nxvrmore_register_settings() {
    register_setting('nxvrmore_options_group', 'nxvrmore_options', 'nxvrmore_options_validate');

    add_settings_section('nxvrmore_main_section', 'Configuración General', 'nxvrmore_section_text', 'nxvrmore-classic-wp');

    add_settings_field('nxvrmore_classic_editor', 'Activar Editor Clásico', 'nxvrmore_classic_editor_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_classic_widgets', 'Activar Widgets Clásicos', 'nxvrmore_classic_widgets_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_permalink_structure', 'Establecer Enlaces Permanentes', 'nxvrmore_permalink_structure_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_disable_admin_bar', 'Deshabilitar Barra de Herramientas', 'nxvrmore_disable_admin_bar_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_remove_default_plugins', 'Eliminar Plugins por Defecto', 'nxvrmore_remove_default_plugins_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_remove_default_content', 'Eliminar Contenido por Defecto', 'nxvrmore_remove_default_content_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_duplicate', 'Activar Duplicar Páginas/Entradas', 'nxvrmore_enable_duplicate_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_custom_php', 'Activar Código PHP Personalizado', 'nxvrmore_enable_custom_php_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_custom_php_code', 'Código PHP Personalizado', 'nxvrmore_custom_php_code_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_enable_custom_js', 'Activar Código JS Personalizado', 'nxvrmore_enable_custom_js_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
    add_settings_field('nxvrmore_custom_js_code', 'Código JS Personalizado', 'nxvrmore_custom_js_code_input', 'nxvrmore-classic-wp', 'nxvrmore_main_section');
}
add_action('admin_init', 'nxvrmore_register_settings');

// Texto de la sección
function nxvrmore_section_text() {
    echo '<p>Configura las opciones del plugin Nxvrmore Classic WP.</p>';
}

// Estilos CSS para los switches y campos de texto
function nxvrmore_admin_styles() {
    echo '
    <style>
    .nxvrmore-switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
    }
    .nxvrmore-switch input { 
        opacity: 0;
        width: 0;
        height: 0;
    }
    .nxvrmore-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 34px;
    }
    .nxvrmore-slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
    }
    input:checked + .nxvrmore-slider {
        background-color: #2196F3;
    }
    input:checked + .nxvrmore-slider:before {
        transform: translateX(26px);
    }
    .nxvrmore-php-code, .nxvrmore-js-code {
        width: 100%;
        height: 200px;
        font-family: monospace;
    }
    .nxvrmore-code-field {
        display: none;
    }
    </style>
    ';
}
add_action('admin_head', 'nxvrmore_admin_styles');

// Script para mostrar/ocultar campos de texto según el estado del switch
function nxvrmore_admin_scripts() {
    echo '
    <script>
    jQuery(document).ready(function($) {
        function toggleCodeFields() {
            if ($("#nxvrmore_enable_custom_php").is(":checked")) {
                $(".nxvrmore-php-code-field").show();
            } else {
                $(".nxvrmore-php-code-field").hide();
            }
            if ($("#nxvrmore_enable_custom_js").is(":checked")) {
                $(".nxvrmore-js-code-field").show();
            } else {
                $(".nxvrmore-js-code-field").hide();
            }
        }
        toggleCodeFields();
        $("#nxvrmore_enable_custom_php, #nxvrmore_enable_custom_js").change(toggleCodeFields);
    });
    </script>
    ';
}
add_action('admin_footer', 'nxvrmore_admin_scripts');

// Campos de entrada con switches personalizados
function nxvrmore_classic_editor_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_classic_editor" name="nxvrmore_options[classic_editor]" value="1" ' . checked(1, $options['classic_editor'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_classic_widgets_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_classic_widgets" name="nxvrmore_options[classic_widgets]" value="1" ' . checked(1, $options['classic_widgets'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_permalink_structure_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_permalink_structure" name="nxvrmore_options[permalink_structure]" value="1" ' . checked(1, $options['permalink_structure'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_disable_admin_bar_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_disable_admin_bar" name="nxvrmore_options[disable_admin_bar]" value="1" ' . checked(1, $options['disable_admin_bar'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_remove_default_plugins_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_remove_default_plugins" name="nxvrmore_options[remove_default_plugins]" value="1" ' . checked(1, $options['remove_default_plugins'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_remove_default_content_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_remove_default_content" name="nxvrmore_options[remove_default_content]" value="1" ' . checked(1, $options['remove_default_content'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_enable_duplicate_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_duplicate" name="nxvrmore_options[enable_duplicate]" value="1" ' . checked(1, $options['enable_duplicate'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_enable_custom_php_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_custom_php" name="nxvrmore_options[enable_custom_php]" value="1" ' . checked(1, $options['enable_custom_php'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_custom_php_code_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <div class="nxvrmore-php-code-field nxvrmore-code-field">
        <textarea id="nxvrmore_custom_php_code" name="nxvrmore_options[custom_php_code]" class="nxvrmore-php-code">' . esc_textarea($options['custom_php_code'] ?? '') . '</textarea>
    </div>
    ';
}

function nxvrmore_enable_custom_js_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <label class="nxvrmore-switch">
        <input type="checkbox" id="nxvrmore_enable_custom_js" name="nxvrmore_options[enable_custom_js]" value="1" ' . checked(1, $options['enable_custom_js'] ?? 0, false) . ' />
        <span class="nxvrmore-slider"></span>
    </label>
    ';
}

function nxvrmore_custom_js_code_input() {
    $options = get_option('nxvrmore_options', array());
    echo '
    <div class="nxvrmore-js-code-field nxvrmore-code-field">
        <textarea id="nxvrmore_custom_js_code" name="nxvrmore_options[custom_js_code]" class="nxvrmore-js-code">' . esc_textarea($options['custom_js_code'] ?? '') . '</textarea>
    </div>
    ';
}

// Página de opciones
function nxvrmore_options_page() {
    ?>
    <div class="wrap">
        <h1>Nxvrmore Classic WP</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('nxvrmore_options_group');
            do_settings_sections('nxvrmore-classic-wp');
            submit_button('Guardar Cambios');
            ?>
        </form>
    </div>
    <?php
}

// Validar opciones
function nxvrmore_options_validate($input) {
    $newinput['classic_editor'] = isset($input['classic_editor']) ? 1 : 0;
    $newinput['classic_widgets'] = isset($input['classic_widgets']) ? 1 : 0;
    $newinput['permalink_structure'] = isset($input['permalink_structure']) ? 1 : 0;
    $newinput['disable_admin_bar'] = isset($input['disable_admin_bar']) ? 1 : 0;
    $newinput['remove_default_plugins'] = isset($input['remove_default_plugins']) ? 1 : 0;
    $newinput['remove_default_content'] = isset($input['remove_default_content']) ? 1 : 0;
    $newinput['enable_duplicate'] = isset($input['enable_duplicate']) ? 1 : 0;
    $newinput['enable_custom_php'] = isset($input['enable_custom_php']) ? 1 : 0;
    $newinput['enable_custom_js'] = isset($input['enable_custom_js']) ? 1 : 0;

    // Validar el código PHP antes de guardarlo
    if (isset($input['custom_php_code']) && !empty($input['custom_php_code'])) {
        $code = $input['custom_php_code'];
        $valid = nxvrmore_validate_php_code($code);
        if ($valid) {
            $newinput['custom_php_code'] = $code;
        } else {
            add_settings_error('nxvrmore_options', 'invalid_php', 'El código PHP contiene errores y no se ha guardado.', 'error');
            $newinput['custom_php_code'] = '';
            $newinput['enable_custom_php'] = 0; // Desactivar si hay errores
        }
    } else {
        $newinput['custom_php_code'] = '';
    }

    // Validar el código JS antes de guardarlo
    if (isset($input['custom_js_code']) && !empty($input['custom_js_code'])) {
        $newinput['custom_js_code'] = $input['custom_js_code'];
    } else {
        $newinput['custom_js_code'] = '';
    }

    return $newinput;
}

// Validar código PHP
function nxvrmore_validate_php_code($code) {
    ob_start();
    $valid = true;
    try {
        eval($code);
    } catch (Throwable $e) {
        $valid = false;
    }
    ob_end_clean();
    return $valid;
}

// Ejecutar código PHP personalizado si está activado
function nxvrmore_execute_custom_php() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['enable_custom_php']) && $options['enable_custom_php'] && !empty($options['custom_php_code'])) {
        try {
            eval($options['custom_php_code']);
        } catch (Throwable $e) {
            // Desactivar el código si hay un error
            $options['enable_custom_php'] = 0;
            update_option('nxvrmore_options', $options);
        }
    }
}
add_action('init', 'nxvrmore_execute_custom_php');

// Insertar código JS en todas las páginas
function nxvrmore_insert_custom_js() {
    $options = get_option('nxvrmore_options', array());
    if (isset($options['enable_custom_js']) && $options['enable_custom_js'] && !empty($options['custom_js_code'])) {
        echo '<script type="text/javascript">' . $options['custom_js_code'] . '</script>';
    }
}
add_action('wp_footer', 'nxvrmore_insert_custom_js');